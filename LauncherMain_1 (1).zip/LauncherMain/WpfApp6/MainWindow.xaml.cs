﻿using ModernWpf.Controls;
using ModernWpf;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp6.Pages;
using ModernWpf.Media.Animation;
using DiscordRPC;
using System;
using System.Net;
using Windows.Media.Protection.PlayReady;
//using WpfApp6.Services;

namespace WpfApp6
{


	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		// Sets Up The Pages
		Home home = new Home();
		Settings settings = new Settings();
		Versions versions = new Versions();
        private DiscordRpcClient client;
        public MainWindow()
		{
			InitializeComponent();
            InitializeDiscordRPC();

           

        }

        private void NavView_Loaded(object sender, RoutedEventArgs e)
		{
			ContentFrame.Navigate(home);

			

			//base.OnStartup(e);
			//ContentFrame.Navigate(home);
		}

		private void NavView_SelectionChanged(ModernWpf.Controls.NavigationView sender, ModernWpf.Controls.NavigationViewSelectionChangedEventArgs args)
		{
			if (args.IsSettingsSelected)
			{
				ContentFrame.Navigate(settings);
			}else
			{
				NavigationViewItem item = args.SelectedItem as NavigationViewItem;

				if (item.Tag.ToString() == "Home")
				{
					ContentFrame.Navigate(home);
				}
				if (item.Tag.ToString() == "Versions")
				{
					ContentFrame.Navigate(versions);
				}
            }
		}

		private void ContentFrame_NavigationFailed(object sender, NavigationFailedEventArgs e)
		{
			throw new Exception("Failed to load Page."); // Never TBH
		}
        private void InitializeDiscordRPC()
        {
            client = new DiscordRpcClient("1187492097394221076");

            client.OnReady += (sender, e) =>
            {
                Console.WriteLine("Discord RPC is ready.");
            };
            client.Initialize();

            DiscordRPC.Button joinButton = new DiscordRPC.Button
            {
                Label = "Join The Discord",
                Url = "https://discord.gg/tiltedfn"
            };

            var buttons = new DiscordRPC.Button[1];
            buttons[0] = joinButton;

            client.SetPresence(new RichPresence
            {
                Details = "Project Tilted",
                State = "Playing Project Tilted",
                Timestamps = Timestamps.Now,
                Assets = new Assets
                {
                    LargeImageKey = "tilted",
                    LargeImageText = "Project Tilted",
                },
                Buttons = buttons
            });
        }
    }
}
