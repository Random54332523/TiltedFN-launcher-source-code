﻿using System;
using System.Net;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using WpfApp6.Services;
using MongoDB.Driver;
using MongoDB.Bson;
using System.IO;
using System.Reflection;
using System.Text;

namespace WpfApp6
{
    public partial class LoadingScreen : Window
    {
        public LoadingScreen()
        {
            InitializeComponent();
            StartLoadingProcess();
        }

        private async void StartLoadingProcess()
        {
            await Task.Delay(1000);
            Dispatcher.Invoke(() => LoadingTextBox.Text = "Checking For Updates...");
            WebClient omg = new WebClient();
            try
            {
                string Version = omg.DownloadString("https://drive.google.com/uc?export=download&id=1FxhBH3XnryqoEjLwJWG3rV9AGPSJw-tU");
                string CurrentVersion = "0.0.5";
                if (!CurrentVersion.Equals(Version))
                {
                    MessageBox.Show("Your launcher is out of date. Please check the discord.");
                    Application.Current.Shutdown();
                    return;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Failed to check the current version. The application will shut down.");
                Application.Current.Shutdown();
                return;
            }

            await Task.Delay(1000);
            Dispatcher.Invoke(() => LoadingTextBox.Text = "Logging in...");

            string storedEmail = UpdateINI.ReadValue("Auth", "Email");
            string storedPassword = UpdateINI.ReadValue("Auth", "Password");

            bool isCredentialsValid = ValidateCredentialsAsync(storedEmail, storedPassword);

            if (!isCredentialsValid) // Show login only if credentials are wrong
            {
                var login = new Login();
                login.Show();
                this.Close(); // Close the loading screen if credentials are wrong
            }
            else
            {
                var mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close(); // Close the loading screen if credentials are correct
            }
        }

        private string GetJsonBody(string url, string body)
        {
            WebRequest webRequest = WebRequest.Create(url);
            webRequest.ContentType = "application/json";
            webRequest.Method = "GET";
            object value = webRequest.GetType().GetProperty("CurrentMethod", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(webRequest);
            value.GetType().GetField("ContentBodyNotAllowed", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(value, false);
            using (StreamWriter streamWriter = new StreamWriter(webRequest.GetRequestStream()))
            {
                streamWriter.Write(body);
            }
            WebResponse webResponse = (HttpWebResponse)webRequest.GetResponse();
            string result = "";
            using (Stream responseStream = webResponse.GetResponseStream())
            {
                result = new StreamReader(responseStream, Encoding.UTF8).ReadToEnd();
            }
            return result;
        }

        private bool ValidateCredentialsAsync(string email, string password)
        {
            try
            {
                /*string connectionString = "mongodb://127.0.0.1";
                string databaseName = "TiltedDatabaseReal";
                var client = new MongoClient(connectionString);
                var database = client.GetDatabase(databaseName);
                var collection = database.GetCollection<BsonDocument>("users");

                var filter = Builders<BsonDocument>.Filter.Eq("email", email) & Builders<BsonDocument>.Filter.Eq("password", password);
                var result = await collection.Find(filter).FirstOrDefaultAsync();

                return result != null; // If result is not null, credentials are valid*/
                return GetJsonBody("http://147.185.221.17:38605/login", $"{{\"email\":\"{email}\", \"password\":\"{password}\"}}") == "true";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
                return false;
            }
        }
    }
}