﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using WpfApp6.Services;
using MongoDB.Driver;
using MongoDB.Bson;
using System.IO;
using System.Net;
using System.Reflection;
using System.Text;

namespace WpfApp6
{
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
            string storedEmail = UpdateINI.ReadValue("Auth", "Email");
            string storedPassword = UpdateINI.ReadValue("Auth", "Password");

            // Set the retrieved values in the TextBox and PasswordBox
            if (storedEmail != "NONE") EmailBox.Text = storedEmail;
            if (storedPassword != "NONE") PasswordBox.Password = storedPassword;
        }

        private string GetJsonBody(string url, string body)
        {
            WebRequest webRequest = WebRequest.Create(url);
            webRequest.ContentType = "application/json";
            webRequest.Method = "GET";
            object value = webRequest.GetType().GetProperty("CurrentMethod", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(webRequest);
            value.GetType().GetField("ContentBodyNotAllowed", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(value, false);
            using (StreamWriter streamWriter = new StreamWriter(webRequest.GetRequestStream()))
            {
                streamWriter.Write(body);
            }
            WebResponse webResponse = (HttpWebResponse)webRequest.GetResponse();
            string result = "";
            using (Stream responseStream = webResponse.GetResponseStream())
            {
                result = new StreamReader(responseStream, Encoding.UTF8).ReadToEnd();
            }
            return result;
        }

        private bool ValidateCredentialsAsync(string email, string password)
        {
            try
            {
                /*string connectionString = "mongodb://127.0.0.1";
                string databaseName = "TiltedDatabaseReal";
                var client = new MongoClient(connectionString);
                var database = client.GetDatabase(databaseName);
                var collection = database.GetCollection<BsonDocument>("users");

                var filter = Builders<BsonDocument>.Filter.Eq("email", email) & Builders<BsonDocument>.Filter.Eq("password", password);
                var result = await collection.Find(filter).FirstOrDefaultAsync();

                return result != null; // If result is not null, credentials are valid*/
                return GetJsonBody("http://147.185.221.17:38605/login", $"{{\"email\":\"{email}\", \"password\":\"{password}\"}}") == "true";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
                return false;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailBox.Text;
            string password = PasswordBox.Password;

            bool isValid = ValidateCredentialsAsync(email, password);

            if (isValid)
            {
                UpdateINI.WriteToConfig("Auth", "Email", email); // Save email to Update.ini
                UpdateINI.WriteToConfig("Auth", "Password", password); // Save password to Update.ini
                var mainWindow = new MainWindow();
                mainWindow.Show();
                // Close the login window
                this.Close();
            }
            else
            {
                UpdateINI.WriteToConfig("Auth", "Email", email); // Save email to Update.ini
                UpdateINI.WriteToConfig("Auth", "Password", password); // Save password to Update.ini
                MessageBox.Show("Invalid email or password");
            }
        }

        private void TextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Add any text input validation if needed
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Handle text changes if needed
        }
    }
}