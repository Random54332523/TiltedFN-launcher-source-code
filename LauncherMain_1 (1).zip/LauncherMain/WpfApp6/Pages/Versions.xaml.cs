﻿/*using System.Diagnostics;
using System.IO.Compression;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using System;
using WpfApp6.Services.Launch;
using WpfApp6.Services;
using MessageBox = System.Windows.Forms.MessageBox;
using UserControl = System.Windows.Controls.UserControl;

public class Vars
{
    public static string Email = "NONE";
    public static string Password = "NONE";
    public static string Path = "NONE";
}

/*public class Launcher
{

    [DllImport("user32.dll")]
    static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    public static void Launch()
    {
        try
        {
            if (Vars.Path == "NONE")
            {
                Vars.Path = UpdateINI.ReadValue("Auth", "Path");
            }
            string GamePath = Vars.Path;
            if (GamePath != "NONE") // NONE THE BEST RESPONSE!
            {
                //MessageBox.Show(Path69);
                if (File.Exists(System.IO.Path.Combine(GamePath, "FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping.exe")))
                {
                    if (Vars.Email == "NONE")
                    {
                        Vars.Email = UpdateINI.ReadValue("Auth", "Email");
                    }
                    if (Vars.Password == "NONE")
                    {
                        Vars.Password = UpdateINI.ReadValue("Auth", "Password");
                    }
                    if (Vars.Email == "NONE" || Vars.Password == "NONE")
                    {
                        MessageBox.Show("Please add your WpfApp6 info in settings!");
                        //this.Close();
                        //(new Form2()).Show();
                        return;
                    }
                    foreach (var proc in Process.GetProcessesByName("WpfApp6EAC"))
                    {
                        if (proc.MainModule.FileName.StartsWith(GamePath))
                        {
                            proc.Kill();
                            proc.WaitForExit();
                        }
                    }
                    foreach (var proc in Process.GetProcessesByName("FortniteClient-Win64-Shipping"))
                    {
                        try
                        {
                            if (proc.MainModule.FileName.StartsWith(GamePath))
                            {
                                proc.Kill();
                                proc.WaitForExit();
                            }
                        } catch {}
                    }
                    WebClient Client = new WebClient();
                    var lookup = new LookupClient();
                    var result = lookup.Query("WpfApp6.ploosh.dev", QueryType.TXT);
                    var record = result.Answers.TxtRecords().FirstOrDefault();
                    var ip = record?.Text.FirstOrDefault();
                    //Client.DownloadFile("https://cdn.discordapp.com/attachments/883144741838020629/1174502844636856380/Cobalt.dll", Path.Combine(Path69, "Engine\\Binaries\\ThirdParty\\NVIDIA\\NVaftermath\\Win64", "GFSDK_Aftermath_Lib.x64.dll"));
                    if (!File.Exists(System.IO.Path.Combine(GamePath, "WpfApp6EAC.exe")))
                    {
                        Client.DownloadFile($"{ip}/assets/WpfApp6EAC.zip", Path.Combine(GamePath, "WpfApp6EAC.zip"));
                        System.IO.Compression.ZipFile.ExtractToDirectory(Path.Combine(GamePath, "WpfApp6EAC.zip"), GamePath);
                        File.Delete(Path.Combine(GamePath, "WpfApp6EAC.zip"));
                        if (File.Exists(System.IO.Path.Combine(GamePath, "WpfApp6EAC.exe")))
                        {
                            var proc = new Process()
                            {
                                StartInfo = new ProcessStartInfo()
                                {
                                    Arguments = $"install bff26fa986424f4b8fa9dd3b6e853df8",
                                    FileName = Path.Combine(GamePath, "EasyAntiCheat", "EasyAntiCheat_EOS_Setup.exe")
                                },
                                EnableRaisingEvents = true
                            };
                            proc.Start();
                            proc.WaitForExit();
                        } else
                        {
                            MessageBox.Show("Failed to download/extract WpfApp6 EAC!");
                        }
                    }
                    if (!File.Exists(Path.Combine(GamePath, "Engine\\Binaries\\ThirdParty\\NVIDIA\\NVaftermath\\Win64", "GFSDK_Aftermath_Lib2.x64.dll")))
                    {
                        File.Move(Path.Combine(GamePath, "Engine\\Binaries\\ThirdParty\\NVIDIA\\NVaftermath\\Win64", "GFSDK_Aftermath_Lib.x64.dll"), Path.Combine(GamePath, "Engine\\Binaries\\ThirdParty\\NVIDIA\\NVaftermath\\Win64", "GFSDK_Aftermath_Lib2.x64.dll"));
                    }
                    Client.DownloadFile($"{ip}/assets/sigs.bin", Path.Combine(GamePath, "EasyAntiCheat\\Certificates", "base.bin"));
                    Client.DownloadFile($"{ip}/assets/GFSDK_Aftermath_Lib.x64.dll", Path.Combine(GamePath, "Engine\\Binaries\\ThirdParty\\NVIDIA\\NVaftermath\\Win64", "GFSDK_Aftermath_Lib.x64.dll"));

                    IntPtr h = Process.GetCurrentProcess().MainWindowHandle;
                    ShowWindow(h, 6);
                    //AntiCheat.Start(Path69);
                    Game.Start(GamePath, "-plooshfn -epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -nobe -fromfl=eac -fltoken=h1cdhchd10150221h130eB56 -skippatchcheck", Vars.Email, Vars.Password);
                    FakeAC.Start(GamePath, "FortniteClient-Win64-Shipping_EAC.exe", $"-epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -nobe -fromfl=eac -fltoken=h1cdhchd10150221h130eB56 -skippatchcheck", "r");
                    FakeAC.Start(GamePath, "FortniteLauncher.exe", $"-epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -nobe -fromfl=eac -fltoken=h1cdhchd10150221h130eB56 -skippatchcheck", "dsf");
                    try
                    {
                        Game._FortniteProcess.WaitForExit();
                    } catch (Exception) {}
                    try
                    {
                        FakeAC._FNLauncherProcess.Close();
                        FakeAC._FNAntiCheatProcess.Close();
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("There has been an error closing Fake AC.");
                    }



                    //Injector.Start(Game._FortniteProcess.Id, Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "EonCurl.dll"));
                }
                else
                {
                    MessageBox.Show("Please add your WpfApp6 info in settings!");
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.ToString());
        }
    }

    public static void Kill()
    {
        try
        {
            Process.GetProcessById(Game._FortniteProcess.Id).Kill();
            FakeAC._FNLauncherProcess.Kill();
            FakeAC._FNAntiCheatProcess.Kill();
        } catch (Exception)
        {

        }
    }
}*/

/*public static class ZipArchiveExtensions
{
    public static void ExtractToDirectory(this ZipArchive archive, string destinationDirectoryName, bool overwrite)
    {
        if (!overwrite)
        {
            archive.ExtractToDirectory(destinationDirectoryName);
            return;
        }

        DirectoryInfo di = Directory.CreateDirectory(destinationDirectoryName);
        string destinationDirectoryFullPath = di.FullName;

        foreach (ZipArchiveEntry file in archive.Entries)
        {
            string completeFileName = Path.GetFullPath(Path.Combine(destinationDirectoryFullPath, file.FullName));

            if (!completeFileName.StartsWith(destinationDirectoryFullPath, StringComparison.OrdinalIgnoreCase))
            {
                throw new IOException("Trying to extract file outside of destination directory. See this link for more info: https://snyk.io/research/zip-slip-vulnerability");
            }

            if (file.Name == "")
            {// Assuming Empty for Directory
                Directory.CreateDirectory(Path.GetDirectoryName(completeFileName));
                continue;
            }
            File.Delete(completeFileName);
            file.ExtractToFile(completeFileName, true);
        }
    }
}

namespace WpfApp6.Pages
{
    /// <summary>
    /// Interaction logic for Versions.xaml
    /// </summary>
    public partial class Versions : UserControl
    {
        Thread launcherThread;
        bool running = false;
        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        public static void DeleteDirectory(string target_dir)
        {
            string[] files = Directory.GetFiles(target_dir);
            string[] dirs = Directory.GetDirectories(target_dir);

            foreach (string file in files)
            {
                File.SetAttributes(file, FileAttributes.Normal);
                File.Delete(file);
            }

            foreach (string dir in dirs)
            {
                DeleteDirectory(dir);
            }

            Directory.Delete(target_dir, false);
        }

        public void Launch()
        {
            try
            {
                if (running) return;
                running = true;
                if (Vars.Path == "NONE")
                {
                    Vars.Path = UpdateINI.ReadValue("Auth", "Path");
                }
                string GamePath = Vars.Path;
                if (GamePath != "NONE") // NONE THE BEST RESPONSE!
                {
                    //MessageBox.Show(Path69);
                    if (File.Exists(System.IO.Path.Combine(GamePath, "FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping.exe")))
                    {
                        if (Vars.Email == "NONE")
                        {
                            Vars.Email = UpdateINI.ReadValue("Auth", "Email");
                        }
                        if (Vars.Password == "NONE")
                        {
                            Vars.Password = UpdateINI.ReadValue("Auth", "Password");
                        }
                        if (Vars.Email == "NONE" || Vars.Password == "NONE")
                        {
                            MessageBox.Show("Please add your Tilted login in settings!");
                            this.Dispatcher.Invoke(() =>
                            {
                                this.Button.Content = "Start Tilted";
                                this.Button.Click += Button_Click;
                                this.Button.IsEnabled = true;
                            });
                            //this.Close();
                            //(new Form2()).Show();
                            return;
                        }
                        foreach (var proc in Process.GetProcessesByName("FusionEAC"))
                        {
                            try
                            {
                                if (proc.MainModule.FileName.StartsWith(GamePath))
                                {
                                    proc.Kill();
                                    proc.WaitForExit();
                                }
                            }
                            catch
                            {
                                MessageBox.Show("Tilted is already running from your game path!");
                                this.Dispatcher.Invoke(() =>
                                {
                                    this.Button.Content = "Start Tilted";
                                    this.Button.Click += Button_Click;
                                    this.Button.IsEnabled = true;
                                });
                                return;
                            }
                        }
                        foreach (var proc in Process.GetProcessesByName("FortniteClient-Win64-Shipping"))
                        {
                            try
                            {
                                if (proc.MainModule.FileName.StartsWith(GamePath))
                                {
                                    proc.Kill();
                                    proc.WaitForExit();
                                }
                            }
                            catch
                            {
                                MessageBox.Show("Fortnite is already running from your game path!");
                                this.Dispatcher.Invoke(() =>
                                {
                                    this.Button.Content = "Start Tilted";
                                    this.Button.Click += Button_Click;
                                    this.Button.IsEnabled = true;
                                });
                                return;
                            }
                        }
                        WebClient Client = new WebClient();
                        //Client.DownloadFile("https://cdn.discordapp.com/attachments/883144741838020629/1174502844636856380/Cobalt.dll", Path.Combine(Path69, "Engine\\Binaries\\ThirdParty\\NVIDIA\\NVaftermath\\Win64", "GFSDK_Aftermath_Lib.x64.dll"));
                        if (!File.Exists(System.IO.Path.Combine(GamePath, "FusionEAC.exe")))
                        {
                            Client.DownloadFile($"https://cdn.discordapp.com/attachments/1180275552179982447/1188529620664983583/FusionEAC.zip", Path.Combine(GamePath, "FusionEAC.zip"));
                            System.IO.Compression.ZipFile.ExtractToDirectory(Path.Combine(GamePath, "FusionEAC.zip"), GamePath);
                            File.Delete(Path.Combine(GamePath, "FusionEAC.zip"));
                            if (File.Exists(System.IO.Path.Combine(GamePath, "FusionEAC.exe")) && Directory.Exists(System.IO.Path.Combine(GamePath, "EasyAntiCheat")))
                            {
                                var proc = new Process()
                                {
                                    StartInfo = new ProcessStartInfo()
                                    {
                                        Arguments = $"install 0e46812ea8ec45e9b67992db9535c553",
                                        FileName = Path.Combine(GamePath, "EasyAntiCheat", "EasyAntiCheat_EOS_Setup.exe")
                                    },
                                    EnableRaisingEvents = true
                                };
                                proc.Start();
                                proc.WaitForExit();
                                if (proc.ExitCode == 1223)
                                {
                                    MessageBox.Show("UAC request denied!");
                                    File.Delete(Path.Combine(GamePath, "FusionEAC.exe"));
                                    DeleteDirectory(Path.Combine(GamePath, "EasyAntiCheat"));
                                    this.Dispatcher.Invoke(() =>
                                    {
                                        this.Button.Content = "Start Tilted";
                                        this.Button.Click += Button_Click;
                                        this.Button.IsEnabled = true;
                                    });
                                    return;
                                }
                                else if (proc.ExitCode != 0)
                                {
                                    MessageBox.Show("Failed to install EAC!");
                                    File.Delete(Path.Combine(GamePath, "FusionEAC.exe"));
                                    DeleteDirectory(Path.Combine(GamePath, "EasyAntiCheat"));
                                    this.Dispatcher.Invoke(() =>
                                    {
                                        this.Button.Content = "Start Tilted";
                                        this.Button.Click += Button_Click;
                                        this.Button.IsEnabled = true;
                                    });
                                    return;
                                }
                            }
                            else
                            {
                                MessageBox.Show("Failed to download/extract EAC!");
                                this.Dispatcher.Invoke(() =>
                                {
                                    this.Button.Content = "Start Tilted";
                                    this.Button.Click += Button_Click;
                                    this.Button.IsEnabled = true;
                                });
                                return;
                            }
                        }
                        else
                        {
                            Client.DownloadFile($"https://cdn.discordapp.com/attachments/1180275552179982447/1188529620664983583/FusionEAC.zip", Path.Combine(GamePath, "FusionEAC.zip"));
                            var fs = new FileStream(Path.Combine(GamePath, "FusionEAC.zip"), FileMode.Open);
                            ZipArchiveExtensions.ExtractToDirectory(new ZipArchive(fs), GamePath, true);
                            fs.Close();
                            File.Delete(Path.Combine(GamePath, "FusionEAC.zip"));
                        }
                        if (!File.Exists(Path.Combine(GamePath, "Engine\\Binaries\\ThirdParty\\NVIDIA\\NVaftermath\\Win64", "GFSDK_Aftermath_Lib2.x64.dll")))
                        {
                            File.Move(Path.Combine(GamePath, "Engine\\Binaries\\ThirdParty\\NVIDIA\\NVaftermath\\Win64", "GFSDK_Aftermath_Lib.x64.dll"), Path.Combine(GamePath, "Engine\\Binaries\\ThirdParty\\NVIDIA\\NVaftermath\\Win64", "GFSDK_Aftermath_Lib2.x64.dll"));
                        }
                        //Client.DownloadFile($"{ip}/assets/sigs.bin", Path.Combine(GamePath, "EasyAntiCheat\\Certificates", "base.bin"));
                        Client.DownloadFile($"https://cdn.discordapp.com/attachments/1186995981280096387/1188333629496119416/Redirect.dll", Path.Combine(GamePath, "Engine\\Binaries\\ThirdParty\\NVIDIA\\NVaftermath\\Win64", "GFSDK_Aftermath_Lib.x64.dll"));
                        //AntiCheat.Start(Path69);this.Dispatcher.Invoke(() =>
                        this.Dispatcher.Invoke(() =>
                        {
                            this.Button.Content = "Starting...";
                        });
                        Game.Start(GamePath, "-plooshfn -epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -nobe -fromfl=eac -fltoken=h1cdhchd10150221h130eB56 -skippatchcheck", Vars.Email, Vars.Password);
                        //FakeAC.Start(GamePath, "WpfApp6EAC.exe", "-plooshfn -epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -nobe -fromfl=eac -fltoken=h1cdhchd10150221h130eB56 -skippatchcheck", "t");
                        FakeAC.Start(GamePath, "FortniteClient-Win64-Shipping_EAC.exe", $"-epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -nobe -fromfl=eac -fltoken=h1cdhchd10150221h130eB56 -skippatchcheck", "r");
                        FakeAC.Start(GamePath, "FortniteLauncher.exe", $"-epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -nobe -fromfl=eac -fltoken=h1cdhchd10150221h130eB56 -skippatchcheck", "dsf");

                        //this.Button.Content = "Stop WpfApp6";
                        //this.Button.Click += Button_Click_Stop;
                        //this.Button.IsEnabled = true;
                        IntPtr h = Process.GetCurrentProcess().MainWindowHandle;
                        ShowWindow(h, 6);
                        this.Dispatcher.Invoke(() =>
                        {
                            this.Button.Content = "Stop Tilted";
                            this.Button.Click += Button_Click_Stop;
                            this.Button.IsEnabled = true;
                        });
                        try
                        {
                            Game._FortniteProcess.WaitForExit();
                        }
                        catch (Exception) { }
                        try
                        {
                            try
                            {
                                Kill();
                            }
                            catch
                            {

                            }
                            this.Dispatcher.Invoke(() =>
                            {
                                this.Button.Content = "Start Tilted";
                                this.Button.Click += Button_Click;
                                this.Button.IsEnabled = true;
                                //if (launcherThread.IsAlive) launcherThread.Abort();
                            });
                        }
                        catch (Exception)
                        {
                            MessageBox.Show("An error occurred while closing Fake AC!");
                            this.Dispatcher.Invoke(() =>
                            {
                                this.Button.Content = "Start Tilted";
                                this.Button.Click += Button_Click;
                                this.Button.IsEnabled = true;
                            });
                        }



                        //Injector.Start(Game._FortniteProcess.Id, Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "EonCurl.dll"));
                        running = false;
                    }
                    else
                    {
                        MessageBox.Show("Selected path is not a valid fortnite installation!");
                        this.Dispatcher.Invoke(() =>
                        {
                            this.Button.Content = "Start Tilted";
                            this.Button.Click += Button_Click;
                            this.Button.IsEnabled = true;
                        });
                    }
                }
                else
                {
                    MessageBox.Show("Please add your game path in settings!");
                    this.Dispatcher.Invoke(() =>
                    {
                        this.Button.Content = "Start Tilted";
                        this.Button.Click += Button_Click;
                        this.Button.IsEnabled = true;
                    });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                this.Dispatcher.Invoke(() =>
                {
                    this.Button.Content = "Start Tilted";
                    this.Button.Click += Button_Click;
                    this.Button.IsEnabled = true;
                });
            }
        }

        public static void Kill()
        {
            try
            {
                if (Game._FortniteProcess != null && !Game._FortniteProcess.HasExited) Process.GetProcessById(Game._FortniteProcess.Id).Kill();
                if (FakeAC._FNLauncherProcess != null && !FakeAC._FNLauncherProcess.HasExited) FakeAC._FNLauncherProcess.Kill();
                if (FakeAC._FNAntiCheatProcess != null && !FakeAC._FNAntiCheatProcess.HasExited) FakeAC._FNAntiCheatProcess.Kill();
            }
            catch (Exception)
            {

            }
        }

        public Versions()
        {
            InitializeComponent();
        }

        private void Button_Click_Stop(object sender, RoutedEventArgs e)
        {
            Kill();
            this.Button.Content = "Start Tilted";
            this.Button.Click -= Button_Click_Stop;
            this.Button.Click += Button_Click;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            launcherThread = new Thread(Launch);
            launcherThread.Start();
            this.Button.Content = "Initializing...";
            this.Button.Click -= Button_Click;
            this.Button.IsEnabled = false;
            //this.PathBox.Text = commonOpenFileDialog.FileName;
        }
    }
}*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using WpfApp6.Services;
using WpfApp6.Services.Launch;

namespace WpfApp6.Pages
{
    /// <summary>
    /// Interaction logic for Versions.xaml
    /// </summary>
    public partial class Versions : UserControl
    {
        public Versions()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string Path69 = UpdateINI.ReadValue("Auth", "Path");
                if (Path69 != "NONE") // NONE THE BEST RESPONSE!
                {
                    //MessageBox.Show(Path69);
                    if (File.Exists(System.IO.Path.Combine(Path69, "FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping.exe")))
                    {
                        if (UpdateINI.ReadValue("Auth", "Email") == "NONE" || UpdateINI.ReadValue("Auth", "Password") == "NONE")
                        {
                            MessageBox.Show("Please Add Your Tilted Login Info In The Login Page");
                            return;
                        }
                        WebClient OMG = new WebClient();
                        OMG.DownloadFile("https://cdn.discordapp.com/attachments/999336953654804550/1191866192986640547/Cobalt.dll", Path.Combine(Path69, "Engine\\Binaries\\ThirdParty\\NVIDIA\\NVaftermath\\Win64", "GFSDK_Aftermath_Lib.x64.dll"));
                        //AntiCheat.Start(Path69);
                        PSBasics.Start(Path69, "-epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -noeac -fromfl=be -fltoken=h1cdhchd10150221h130eB56 -skippatchcheck", UpdateINI.ReadValue("Auth", "Email"), UpdateINI.ReadValue("Auth", "Password"));
                        FakeAC.Start(Path69, "FortniteClient-Win64-Shipping_BE.exe", $"-epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -noeac -fromfl=be -fltoken=h1cdhchd10150221h130eB56 -skippatchcheck", "r");
                        FakeAC.Start(Path69, "FortniteLauncher.exe", $"-epicapp=Fortnite -epicenv=Prod -epiclocale=en-us -epicportal -noeac -fromfl=be -fltoken=h1cdhchd10150221h130eB56 -skippatchcheck", "dsf");
                        PSBasics._FortniteProcess.WaitForExit();
                        try
                        {
                            FakeAC._FNLauncherProcess.Close();
                            FakeAC._FNAntiCheatProcess.Close();
                        }
                        catch (Exception)
                        {
                            MessageBox.Show("There Been A Error Closing The Application");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Add Your 9.10 Path In Settings"); // INV
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("There was an error that is unknown");
            }

        }


        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }
    }
}



