﻿using System;
using System.Windows.Controls;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using WpfApp6.Services;
using System.IO;
using System.Net;
using System.Reflection;
using System.Text;

namespace WpfApp6.Pages
{
    public partial class Home : Page
    {
        //private IMongoCollection<User> _userCollection;

        public Home()
        {
            InitializeComponent();
            LoadUsernameFromMongoDB();
        }

        private string GetJsonBody(string url, string body)
        {
            WebRequest webRequest = WebRequest.Create(url);
            webRequest.ContentType = "application/json";
            webRequest.Method = "GET";
            object value = webRequest.GetType().GetProperty("CurrentMethod", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(webRequest);
            value.GetType().GetField("ContentBodyNotAllowed", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(value, false);
            using (StreamWriter streamWriter = new StreamWriter(webRequest.GetRequestStream()))
            {
                streamWriter.Write(body);
            }
            WebResponse webResponse = (HttpWebResponse)webRequest.GetResponse();
            string result = "";
            using (Stream responseStream = webResponse.GetResponseStream())
            {
                result = new StreamReader(responseStream, Encoding.UTF8).ReadToEnd();
            }
            return result;
        }

        private void LoadUsernameFromMongoDB()
        {
            try
            {
                // Read email from the INI file
                /*string storedEmail = UpdateINI.ReadValue("Auth", "Email");

                // MongoDB connection setup
                string connectionString = "mongodb://127.0.0.1";
                string databaseName = "TiltedDatabaseReal";

                var client = new MongoClient(connectionString);
                var database = client.GetDatabase(databaseName);

                _userCollection = database.GetCollection<User>("users");

                // Find user by email
                var filter = Builders<User>.Filter.Eq(u => u.Email, storedEmail);

                var projectionDefinition = Builders<User>.Projection
                    .Include(u => u.Username)
                    .Include(u => u.Email);

                var user = _userCollection.Find(filter).Project<User>(projectionDefinition).FirstOrDefault();*/
                string storedEmail = UpdateINI.ReadValue("Auth", "Email");
                var user = GetJsonBody("http://147.185.221.17:38605/username", $"{{\"email\":\"{storedEmail}\"}}");

                // Display username in the UsernameTextBox
                if (user != "")
                {
                    UsernameTextBox.Text = user.Length > 25 ? user.Substring(0, 25) : user;
                }
                else
                {
                    UsernameTextBox.Text = "Username not found for this email.";
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions here, e.g., log the error or display a message
                UsernameTextBox.Text = $"Error: {ex.Message}";
            }
        }
    }

    public class User
    {
        [BsonId]
        public ObjectId Id { get; set; }

        [BsonElement("username")]
        public string Username { get; set; }

        [BsonElement("email")]
        public string Email { get; set; }

        [BsonElement("banned")]
        public bool Banned { get; set; } // Adjust the data type based on the actual field type in MongoDB

    }
}