﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using WindowsAPICodePack.Dialogs;
using WpfApp6.Services;

namespace WpfApp6.Pages
{
    public partial class Settings : UserControl
    {
        public Settings()
        {
            InitializeComponent();

        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            CommonOpenFileDialog commonOpenFileDialog = new CommonOpenFileDialog();
            commonOpenFileDialog.IsFolderPicker = true;
            commonOpenFileDialog.Title = "Select A Fortnite Build";
            commonOpenFileDialog.Multiselect = false;
            CommonFileDialogResult commonFileDialogResult = commonOpenFileDialog.ShowDialog();


            bool flag = commonFileDialogResult == CommonFileDialogResult.Ok;
            if (flag)
            {
                if (File.Exists(System.IO.Path.Combine(commonOpenFileDialog.FileName, "FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping.exe")))
                {
                    this.PathBox.Text = commonOpenFileDialog.FileName;
                }
                else
                {
                    MessageBox.Show("Please make sure that your the folder contains FortniteGame and Engine In");

                }
            }
        }

        private void PathBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateINI.WriteToConfig("Auth", "Path", PathBox.Text); // Updates Live OMG!
        }
        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            // Edit On Release Logic
        }
        private void Button_Click3(object sender, RoutedEventArgs e)
        {
            // Instant Reset Logic
        }

        private void Button_Click4(object sender, RoutedEventArgs e)
        {
            // Assuming MainWindow is the parent window
            Window parentWindow = Window.GetWindow(this);

            if (parentWindow != null)
            {
                MainWindow mainWindow = parentWindow as MainWindow;

                // Create a new instance of the login window
                Login loginWindow = new Login();

                // Show the login window
                loginWindow.Show();

                // Close the current (main) window
                mainWindow.Close();
            }
        }
    }
}